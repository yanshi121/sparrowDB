HOST: str = "127.0.0.1"
PORT: int = 712
TRY_MODEL: bool = True
SHOW_ERROR: bool = True
LOG_FILE: str = "test.log"
DEFAULT_LISTEN: int = 1
IS_SAVE_LOG: bool = False
