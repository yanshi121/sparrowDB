# 默认启动ip
HOST: str = "127.0.0.1"
# 默认端口
PORT: int = 712
# try模式
TRY_MODEL: bool = True
# 是否显示错误信息
SHOW_ERROR: bool = True
# 日志记录文件名
LOG_FILE: str = "sparrow.log"
# 监听端口数量
DEFAULT_LISTEN: int = 1
# 是否保存日志到文件
IS_SAVE_LOG: bool = False
